rm(list=ls())
### 1.缺失值的识别
#  (1)缺失值识别
library(mice)  #载入mice程序包
data(nhanes2)  #载入数据集nhanes2
a<-is.na(nhanes2)  #每个观测值缺失情况
head(a)  #head展示结果的前六行
b<-complete.cases(nhanes2)  #每行数据缺失情况
head(b)
#  (2)列表显示缺失值
md.pattern(nhanes2)  #列表显示缺失值
#  (3)图形探索缺失值
library("VIM")
aggr(nhanes2,number=T,prop=T)  #图形展示缺失值
help(aggr)
### 3.缺失值的处理方法
#  (1)行删除法
mydata<-nhanes2[complete.cases(nhanes2),]
mydata<-nhanes2
sum(!complete.cases(mydata))  #删除前不完整行数
newdata<-na.omit(mydata)  #  行删除
sum(!complete.cases(newdata))  #删除后不完整行数
#  (2)均值/中位数/众数插值法
library(Hmisc)
impute(nhanes2$chl,mean)  #均值插补
impute(nhanes2$chl)   #中位数插补
sort(table(nhanes2$chl))  #先求频数再排序观察众数
impute(nhanes2$chl,187)  #众数插补
#  (3)回归插值法
library(DMwR)
data("algae")
help("algae")
#探索相关关系
symnum(cor(algae[,4:18],use="complete.obs"))
#计算线性关系
lm(PO4~oPO4,data=algae)
#构造函数计算缺失值的估计值
PO4_es<-function(x)
{
  if(is.na(x))
    return(NA)
  else
    return(1.293*x+42.897)
}
#对缺失值进行插补
algae[is.na(algae$PO4),"PO4"]<-
  sapply(algae[is.na(algae$PO4),"oPO4"],PO4_es)
#  (4)热平台插补法
data(nhanes2,package="mice")
#存在缺失值的样本
missing_Y=nhanes2[which(apply(is.na(nhanes2),1,sum)!=0),] 
missing_Y[1,]  #查看存在缺失值数据集的第一行数据
#无缺失值样本
missing_N=nhanes2[which(apply(is.na(nhanes2),1,sum)==0),] 
missing_N[1,]  #查无缺失值数据集的第一行数据
missing_Y[2,]
#在missing_N中寻找相似样本
si<-missing_N[which(missing_N[,1]==missing_Y[2,1]&
                      missing_N[,3]==missing_Y[2,3]&
                      missing_N[,4]==missing_Y[2,4]),]
missing_Y[2,2]<-si[1,2]
missing_Y[2,]
#冷平台插补法
# 按照变量age和hyp分层
group1=missing_N[which(missing_N$age=="20-39"&missing_N$hyp=="no"),]
group1
missing_Y[2,2]<-mean(group1$bmi)
missing_Y[2,]
#  (5)多重插补法
library(mice)
imp<-mice(nhanes2,method="cart",seed=1234)
fit<-with(imp,lm(bmi ~ chl))
pooled<-pool(fit)  #对fit中统计结果进行汇总
summary(pooled)
imp$imp$chl  #查看变量chl的5次插补值
dataset3<-complete(imp,action=3)  #查看第三个完整数据集
head(dataset3)  #展示结果前6行
help(mice)