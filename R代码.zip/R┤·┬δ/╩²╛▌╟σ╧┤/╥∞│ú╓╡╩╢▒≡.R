rm(list=ls())
### 2.异常值的识别
#  (1)数字异常值法
library(DMwR)
data("iris")
boxplot(iris$Sepal.Width)  #绘制箱线图
boxplot.stats(iris$Sepal.Width)$out  #展示异常值
#  (2)LOF法
library(DMwR)
iris2<-iris[,1:4] #移除数据集中因子型变量
out_scores<-lofactor(iris2,k=5)  #计算每个样本的LOF值
plot(density(out_scores))  #绘制LOF值的概率密度图
out<-order(out_scores,decreasing = T)[1:5]  #对LOF值降序排列，排名前5的数据视为异常值，提取其样本号
iris2[out,]  #异常值数据
out_scores
help(iris)
density(out_scores)
#  (3)聚类法
library(DMwR)
iris2<-iris[,1:4] #移除数据集中因子型变量
kmeans_result<-kmeans(iris2,centers=3)  #kmeans聚类（设定3类）
kmeans_result$centers  #输出聚类中心
kmeans_result$cluster  #输出聚类结果
centers<-kmeans_result$centers[kmeans_result$cluster,]  #返回每个样本对应的聚类中心样本
distances<-sqrt(rowSums((iris2-centers)^2))  #计算每个样本到其聚类中心的距离
out<-order(distances,decreasing=T)[1:5]  #对距离进行降序排列，将前五个认定为异常值，out中存储的是异常值的样本
iris2[out,]  #异常值