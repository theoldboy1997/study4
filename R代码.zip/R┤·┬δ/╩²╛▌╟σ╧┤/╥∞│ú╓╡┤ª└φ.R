number=iris$Sepal.Width
boxplot(number,main='origin')
boxplot.stats(number)$out
shapiro.test(number)

##盖帽法
q1=quantile(number,0.01)   ##计算出0.01分位数
q1
q99=quantile(number,0.99)  ##计算出0.99分位数
q99
number[which(number>q99)]=q99  ##将大于0.99分位数的数据都赋值为0.99分位数
number[which(number<q1)]=q1   ##将小于0.01分位数的数据都赋值为0.01分位数

par(mfrow=c(1,2)) 
boxplot(number,main='new')




        