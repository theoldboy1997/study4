##直接纵向合并
ID=c(1,2,3,4)
name=c('A','B','C','D')
student1=data.frame(ID,name) ##构建第一个数据集
sdudent1

ID=c(5,6,7,8)
name=c('E','F','G','H')
student2=data.frame(ID,name) ##构建第二个数据集
student2

Total_studuent=rbind(student1,student2) ##合并数据集
Total_studuent

##间接纵向合并
rm(list=ls())
setwd('..\\工作目录')
files=list.files()  ##读取该目录下所有的文件
df=read.table(files[1],header=F,fill=T,sep='',skip=2)#去除第一行读取文件
df=df[1:nrow(df)-1,] #去除最后一行
for(i in 2:length(files)) #通过for循环遍历所有文件
  dfpre=read.table(files[i],header=F,fill=T,sep='',skip=2)
  dfpre=dfpre[1:nrow(dfpre)-1,]
  df=rbind(df,dfpre)
write.csv(df,file='数据合并.csv',row.names = F) ##读出文件

##横向合并
x=data.frame(name=c('John','Paul','George','Ringo','Stuart','Pete'),
             instrument=c('guitar','bass','guitar','drums','bass','drums'))
x  ##构建第一个数据集

y=data.frame(name=c('John','Paul','George','Ringo','Brian'),
             band=c('TRUE','TURE','TRUE','TRUE','FALSE'))
y  ##构建第二个数据集

data1=join(x,y,by='name',type='inner')
data1

data2=join(x,y,by='name',type='left')
data2

data3=join(x,y,by='name',type='right')
data3

data4=join(x,y,by='name',type='full')
data4








