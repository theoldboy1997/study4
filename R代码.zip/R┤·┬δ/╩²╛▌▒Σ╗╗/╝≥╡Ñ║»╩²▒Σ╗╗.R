setwd("..//R的工作路径")
##对数变换
mydata=read.csv("lipstick.csv")
apply(mydata[,5:6],2,mean)  ##计算口红总评价数与总销量的均值
newdata=log(mydata[,5:6]+10^-3)  ##由于评价数有0，则用10^-3防止求对数无意义
apply(newdata,2,mean) ##计算对数后的均值
par(mfrow=c(1,2))
boxplot((mydata[,5:6]))  #作出变化前后的箱线图
boxplot(newdata)

##Box-cox变换
set.seed(1000)
par(mfrow=c(2,2),oma=c(2,2,2,2))
x1=rchisq(1000,2,ncp=0)#抽取1000个自由度为2的卡方分布，右偏分布
x2=max(x1)-x1  #得到左偏分布变量x2
library(e1071)
plot(density(x2),main=paste("left,level=",
                            round(skewness(x2),2)),xlab="x2") ##绘制右偏分布密度曲线图
plot(density(x1),main=paste("right,level=",
                            round(skewness(x1),2)),xlab="x1") ##绘制左偏分布密度曲线图

library(MASS)
tmp1=boxcox(x1~1)
lamda=tmp1$x[which.max(tmp1$y)]
lamda
hist(x1,main="origin data")  ##作出原数据直方图
hist(x1^lamda-1/lamda,main="new data") ##作出变换数据直方图
shapiro.test(x1) ##对原数据进行W检验
shapiro.test(x1^lamda-1/lamda) ##对BOX-COX变换后的数据进行W检验

##差分运算
y=scan('..//股票收盘价.txt') 
y1=ts(y,start=1,frequency = 1)  ##转化为时序数据
plot(y1,ylab="收盘价",main="某股票连续若干天收盘价时序图")
y1.diff=diff(y1,1,2) ##对原序列作二阶差分
plot(y1.diff,ylab="收盘价",main="序列二阶差分时序图")
library(tseries)   ##adf检验
adf.test(y1)
adf.test(y1.diff)