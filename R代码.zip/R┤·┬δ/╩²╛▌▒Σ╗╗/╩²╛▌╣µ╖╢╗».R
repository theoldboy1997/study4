setwd('C:/Users/dell/Documents/学年论文')
data=read.csv('lipstick.csv')
range=apply(data[,1:4],2,max)-apply(data[,1:4],2,min)##计算每列的极差
data1=(data[,1:4])-apply(data[,1:4],2,min)/range  ##极差规范化
data2=scale(data[,1:4],center=T) ##零均值规范化

##小数定标化
r=c()
for(i in 1:4)
  r[i]=ceiling(log(max(abs(data[,i])),10))
描述分=data[,1]/10^r[1]
价格分=data[,2]/10^r[2]
质量分=data[,3]/10^r[3]
服务分=data[,4]/10^r[4]
data3=cbind(描述分,价格分,质量分,服务分)

##图示化
par(mfrow=c(2,2))
boxplot(data[,1:4],main='原数据')
boxplot(data1,main='极差规格化变换')
boxplot(data2,main='零均值规格化')
boxplot(data3,main='小数规范化')

