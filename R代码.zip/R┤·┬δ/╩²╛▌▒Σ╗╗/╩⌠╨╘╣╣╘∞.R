setwd("C://Users//dell//Documents//学年论文")
inputfile=read.csv('electricity_data.csv',header=T) ##读取数据
loss=(inputfile[,1]-inputfile[,2])/(inputfile[,1]) ##构造属性
los