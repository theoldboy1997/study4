###1.属性规约
#(1)主成分分析
library(DMwR)
data("iris")
mydata<-iris[,1:4]  #提取数值型变量
PAC=princomp(mydata,cor=T)  #用数据的相关阵进行主成分分析
summary(PAC)  #主成分方差贡献率情况
screeplot(PAC,type="l")  #碎石图
PAC$loadings  #主成分载荷
head(PAC$scores[,1:2])  #部分主成分得分
#（2）决策树分类
library(DMwR)
data("iris")
library(party)
(tree=ctree(Species~.,data=iris))  #条件推断决策树
names(iris)  #原数据集中包含的变量
plot(tree)  #绘制决策树
###2.数值规约
#（1）直方图
library(DMwR)
data("iris")
(x<-hist(iris$Sepal.Width,breaks=12))  #设定分组为12，绘制直方图
#(2)抽样
a<-sample(1:nrow(iris),5,replace=F)  #无重置的简单随机抽样
iris[a,]  #抽样得到的数据
library(sampling)
#以Species为分层变量，采取不重置简单随机抽样的方式从每层抽取3个变量
m<-strata(c("Species"),size=c(3,3,3),method="srswor",data=iris)  
getdata(iris,m)  #获取层层抽样样本数据
